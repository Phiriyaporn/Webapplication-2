// --------------------------Navbar Left----------------------------
// ALWAYS START AT TOP OF SCREEN
window.addEventListener("load", function() {
    setTimeout(function() {
        window.scrollTo(0, 1);
    }, 0);
});

// INITIALIZE NAVBAR
$(document).ready(function() {

    initNavbar();
});

// NAVBAR SCROLLING 
$(function() {

    $('a[href*=\\#]').on('click', function(event) {
        event.preventDefault();
        $('html,body').animate({ scrollTop: $(this.hash).offset().top }, 300);

    });
});

$("#ca_page-wrapper").scrollspy({ target: "#ca_sidenav" });

$('[data-spy="scroll"]').each(function() {
    var $spy = $(this).scrollspy('refresh');
})

// CHANGE NAVBAR ICONS ON SCROLL
// $(".nav2").on("activate.bs.scrollspy", function() {

//     var active = $(".nav2 li.active").index();

//     if (active != NowActive) {

//         // turn off the old button
//         $("#" + NavLinks[NowActive]).css("background-image", "url('images/" + NavImgs[NowActive] + "-off.png')");

//         turnOffHighlight(NowActive);

//         $("#" + NavLinks[NowActive]).animate({ zoom: '98%' }, 100);

//         // turn on the new button
//         $("#" + NavLinks[active]).css("background-image", "url('images/" + NavImgs[active] + "-on.png')");

//         turnOnHighlight(active);

//         $("#" + NavLinks[active]).animate({ zoom: '103%' }, 100);

//         NowActive = active;
//     }

// })

var NavVisible = false;
var NowActive = 0;
var ClickTarget = 0;
// var NavLinks = ['ca_nav0', 'ca_nav1', 'ca_nav2', 'ca_nav3', 'ca_nav4', 'ca_nav5'];
// var NavImgs = ['icon0', 'icon1', 'icon2', 'icon3', 'icon4', 'icon5'];

function initNavbar() {

    NowActive = 0;
    ClickTarget = 0;

    // $(".CA_navHighlight").hide();

    $('#ca_navToggle img').attr("src", "images/menu-up.png");

    // turn on first button
    // $("#" + NavLinks[NowActive]).css("background-image", "url(images/" + NavImgs[NowActive] + "-on.png)");
    // $("#" + NavLinks[NowActive] + " .CA_navHighlight").css("background-color", "lime");

    NavVisible = true;
}

// SLIDE THE NAVBAR DOWN / UP
function toggleNavbar() {

    if (NavVisible) {

        $("#ca_sidenav").addClass("CA_hideNav");
        $('#ca_navToggle img').attr("src", "images/menu-down.png");

        NavVisible = false;

    } else {

        $("#ca_sidenav").removeClass("CA_hideNav");
        $('#ca_navToggle img').attr("src", "images/menu-up.png");

        NavVisible = true;
    }
}

// SLIDE THE NAVBAR LEFT / RIGHT
function slideNavbar() {

    var sideNav = $("#ca_sidenav");

    if (NavVisible) {

        sideNav.css("width", "49px");
        sideNav.removeClass("CA_slideNavRight");
        sideNav.addClass("CA_slideNavLeft");

        $('#ca_navToggle img').attr("src", "images/menu-down.png");

        // $(".CA_navHighlight").show(600);

        NavVisible = false;

    } else {

        sideNav.css("width", "100px");
        sideNav.removeClass("CA_slideNavLeft");
        sideNav.addClass("CA_slideNavRight");

        $('#ca_navToggle img').attr("src", "images/menu-up.png");

        // $(".CA_navHighlight").hide(0);

        NavVisible = true;
    }
}

// CHANGE NAVBAR ICONS ON CLICK
// function navButtonClick(nbc) {

//     ClickTarget = nbc;

//     $("#" + NavLinks[ClickTarget]).animate({ zoom: '98%' }, 100);
//     $("#" + NavLinks[NowActive]).animate({ zoom: '103%' }, 100);

// }

// function turnOffHighlight(index) {

//     var highlight = $("#" + NavLinks[index] + " .CA_navHighlight");
//     highlight.css("background", "transparent");
//     highlight.css("margin-left", "31px");
// }

// function turnOnHighlight(index) {

//     highlight = $("#" + NavLinks[index] + " .CA_navHighlight");
//     highlight.css("background-color", "lime");
//     highlight.css("margin-left", "29px"); // corrects for the zoom
// }

// ---------------------------------------------